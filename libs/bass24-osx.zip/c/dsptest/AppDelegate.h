/*
	BASS DSP example
	Copyright (c) 2000-2021 Un4seen Developments Ltd.
*/

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end

