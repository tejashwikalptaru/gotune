/*
	BASS DSP example
	Copyright (c) 2000-2021 Un4seen Developments Ltd.
*/

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	return NSApplicationMain(argc, argv);
}
